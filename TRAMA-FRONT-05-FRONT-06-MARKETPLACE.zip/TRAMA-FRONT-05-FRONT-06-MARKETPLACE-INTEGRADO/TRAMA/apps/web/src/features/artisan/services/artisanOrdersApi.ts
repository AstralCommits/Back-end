import { mockOrders, type ArtisanOrder, type ProductionStatus } from '../data/mockOrders';

export type ArtisanOrdersApi = {
  listOrders: (input: { month: string }) => Promise<ArtisanOrder[]>;
  updateProductionStatus: (orderId: string, status: ProductionStatus) => Promise<ArtisanOrder>;
};

// Estado em memória para a demonstração enquanto a API não é disponibilizada.
let inMemoryOrders: ArtisanOrder[] = mockOrders.map((order) => ({ ...order }));

const wait = (milliseconds: number) => new Promise((resolve) => setTimeout(resolve, milliseconds));

/**
 * Contrato usado pela tela: listOrders({ month }) e updateProductionStatus().
 * O endpoint real deve ser informado pelo backend; esta camada não presume URL.
 */
export const mockArtisanOrdersApi: ArtisanOrdersApi = {
  async listOrders({ month }) {
    await wait(180);
    return inMemoryOrders
      .filter((order) => !month || order.createdAt.startsWith(month))
      .map((order) => ({ ...order }));
  },

  async updateProductionStatus(orderId, productionStatus) {
    await wait(250);
    const index = inMemoryOrders.findIndex((order) => order.id === orderId);
    if (index < 0) throw new Error('Pedido não encontrado nos dados demonstrativos.');

    inMemoryOrders[index] = { ...inMemoryOrders[index], productionStatus };
    return { ...inMemoryOrders[index] };
  },
};
